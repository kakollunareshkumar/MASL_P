package com.demo.azure.profile;

import com.demo.azure.authz.security.authentication.DelegatedAuthentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/me")
public class ProfileController {

    @GetMapping
    public Profile profile() {
        DelegatedAuthentication auth = (DelegatedAuthentication) SecurityContextHolder.getContext().getAuthentication();
        System.out.println(auth.getPrincipal());
        return Profile.builder()
                .id(auth.getUserId())
                .displayName(auth.getAttributeAsString("given_name"))
                .mail(auth.getName())
                .build();
    }
}
