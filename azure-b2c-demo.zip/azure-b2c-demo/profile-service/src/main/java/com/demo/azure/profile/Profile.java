package com.demo.azure.profile;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class Profile {
    private final String id;
    private final String userPrincipalName;
    private final String businessPhones;
    private final String displayName;
    private final String mail;
    private final String mobilePhone;
    private final String officeLocation;
    private final String surname;
}
