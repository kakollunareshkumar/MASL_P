rootProject.name = "azure-b2c-demo"
include(":auth-component", ":profile-service", ":account-service")
