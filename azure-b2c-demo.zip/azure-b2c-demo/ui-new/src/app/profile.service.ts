import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { Profile } from './profile';
import {HttpClient} from "@angular/common/http";
import {urls} from "./auth-config";

@Injectable({
    providedIn: 'root'
})
export class ProfileService {

    constructor(private httpClient: HttpClient) { }

    getProfile(): Observable<Profile> {
        return this.httpClient.get<Profile>(urls.profileUrl);
    }
}
