export const urls = {
    profileUrl: "http://localhost:8080/me",
    allUsers: "",
    authority: "",
    readUserScope: ""
}
