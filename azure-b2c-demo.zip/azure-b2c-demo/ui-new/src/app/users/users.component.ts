import {Component, OnInit} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Profile} from "../profile";
import {urls} from "../auth-config";

@Component({
    selector: 'app-users',
    templateUrl: './users.component.html',
    styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {

    userResponse: string | undefined = "unknown user";

    constructor(private httpClient: HttpClient) {
    }

    ngOnInit(): void {
        this.httpClient.get(urls.allUsers).subscribe(data => {
            console.log(data);
            this.userResponse = JSON.stringify(data);
        });
    }
}
