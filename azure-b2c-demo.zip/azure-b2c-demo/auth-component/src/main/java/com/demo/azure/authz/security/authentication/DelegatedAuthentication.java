package com.demo.azure.authz.security.authentication;

import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;

import java.time.Instant;
import java.util.Date;
import java.util.Objects;

public class DelegatedAuthentication extends AbstractAuthenticationToken  {

    private final JwtAuthenticationToken delegatedToken;

    public DelegatedAuthentication(JwtAuthenticationToken token) {
        super(token.getAuthorities());
        setAuthenticated(true);
        this.delegatedToken = token;
    }

    public String getIdentityProvider() {
        return getAttributeAsString("idp");
    }

    public String getName() {
        return getAttributeAsString("name");
    }

    public String getUserId() {
        return getAttributeAsString("oid");
    }

    public boolean isNewUser() {
        return Boolean.parseBoolean(getAttributeAsString("newUser"));
    }

    public String clientId() {
        return getAttributeAsString("azp");
    }

    public Date getIssuedAt() {
        return Date.from((Instant) Objects.requireNonNull(getAttribute("iat")));
    }

    public Date getExpiresAt() {
        return Date.from((Instant)Objects.requireNonNull(getAttribute("exp")));
    }

    public Date getNotBefore() {
        return Date.from((Instant)Objects.requireNonNull(getAttribute("nbf")));
    }

    public String getAttributeAsString(String key) {
        return String.valueOf(getAttribute(key));
    }

    public Object getAttribute(String key) {
        return this.delegatedToken.getTokenAttributes().get(key);
    }

    @Override
    public Object getCredentials() {
        return delegatedToken.getCredentials();
    }

    @Override
    public Object getPrincipal() {
        return delegatedToken.getPrincipal();
    }
}
