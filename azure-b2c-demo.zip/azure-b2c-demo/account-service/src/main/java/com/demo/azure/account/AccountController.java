package com.demo.azure.account;

import com.demo.azure.authz.security.authentication.DelegatedAuthentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/v1/accounts")
public class AccountController {

    @GetMapping
    public String greet() {
        DelegatedAuthentication auth = (DelegatedAuthentication) SecurityContextHolder.getContext().getAuthentication();
        return "Hello " + auth.getName() + " welcome in the azure world";
    }
}
