plugins {
    java
    id("org.springframework.boot") version "2.7.11" apply false
    id("io.spring.dependency-management") version "1.1.0" apply false
}

group = "com.demo.azure"
version = "0.0.1-SNAPSHOT"
java.sourceCompatibility = JavaVersion.VERSION_11

configurations {
    compileOnly {
        extendsFrom(configurations.annotationProcessor.get())
    }
}

allprojects {
    repositories {
        mavenLocal()
        mavenCentral()
    }
}

dependencies {
//    implementation("com.azure.spring:spring-cloud-azure-starter-active-directory")
}

tasks.withType<Test> {
    useJUnitPlatform()
}
